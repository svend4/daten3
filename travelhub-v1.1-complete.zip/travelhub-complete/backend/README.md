# TravelHub Backend

Node.js + Express API сервер

## Установка

```bash
npm install
```

## Запуск

```bash
npm run dev
```

## Production

```bash
npm run build
npm start
```
