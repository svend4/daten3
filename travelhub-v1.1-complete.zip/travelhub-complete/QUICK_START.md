# 🚀 Быстрый старт TravelHub

## 📦 Содержимое архива

```
travelhub-complete/
├── README.md                 # Общая информация
├── QUICK_START.md           # Этот файл
├── .gitignore               # Git исключения
│
├── documentation/           # 📚 Документация
│   ├── 01_старый_анализ.md    # Анализ оригинального сайта
│   ├── 02_план_модернизации.md # Roadmap и архитектура
│   ├── 03_дизайн_система.md    # Дизайн-система
│   └── 04_api_интеграция.md    # API партнёров
│
├── frontend/                # ⚛️ React приложение
│   ├── src/
│   │   ├── components/      # UI компоненты
│   │   ├── pages/          # Страницы
│   │   ├── styles/         # Глобальные стили
│   │   ├── App.tsx         # Главный компонент
│   │   └── main.tsx        # Entry point
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   └── index.html
│
├── backend/                 # 🚀 Node.js API
│   ├── src/
│   │   └── index.ts        # API сервер
│   ├── package.json
│   ├── tsconfig.json
│   └── .env.example
│
└── design/                  # 🎨 Дизайн
    └── prototype.html       # Интерактивный прототип
```

## ⚡ Запуск за 5 минут

### 1. Frontend

```bash
cd frontend
npm install
npm run dev
```

Откройте http://localhost:3001

### 2. Backend

```bash
cd backend
npm install
npm run dev
```

API доступен на http://localhost:3000

### 3. Прототип

Откройте `design/prototype.html` в браузере

## 📚 Следующие шаги

1. **Изучите документацию** в папке `documentation/`
2. **Настройте API ключи** в `backend/.env`
3. **Кастомизируйте дизайн** в `frontend/src/styles/`
4. **Добавьте функции** следуя плану в документации

## 🔑 Необходимые API ключи

- Booking.com: https://www.booking.com/affiliate
- Skyscanner: https://partners.skyscanner.net
- Amadeus: https://developers.amadeus.com

## 💡 Полезные команды

```bash
# Frontend
npm run dev          # Запуск dev сервера
npm run build        # Сборка для продакшена
npm run lint         # Проверка кода
npm test             # Запуск тестов

# Backend
npm run dev          # Запуск dev сервера
npm run build        # Компиляция TypeScript
npm start            # Запуск продакшен версии
```

## 🤝 Поддержка

Все файлы готовы к использованию!

Создано с помощью Claude AI - Декабрь 2025
