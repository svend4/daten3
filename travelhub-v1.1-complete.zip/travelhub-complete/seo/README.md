# 🎯 SEO Setup Guide

## 1. Базовая настройка

### Скопируйте SEO файлы

```bash
# Sitemap
cp seo/sitemap.xml frontend/public/

# Robots.txt
cp seo/robots.txt frontend/public/
```

### Обновите URL в файлах

Замените `travelhub.com` на ваш домен в:
- `sitemap.xml`
- `robots.txt`

## 2. Google Search Console

1. Перейдите на https://search.google.com/search-console
2. Добавьте ваш сайт
3. Подтвердите владение (HTML тег или DNS)
4. Отправьте sitemap: `https://yourdomain.com/sitemap.xml`

## 3. Google Analytics

1. Создайте аккаунт на https://analytics.google.com
2. Получите Tracking ID (G-XXXXXXXXXX)
3. Добавьте в `.env`:
```
VITE_GA_TRACKING_ID=G-XXXXXXXXXX
```

## 4. Meta теги

В каждой странице используйте SEOHead компонент:

```typescript
<SEOHead
  title="Ваш заголовок"
  description="Описание страницы до 160 символов"
  keywords="ключевые, слова, через, запятую"
/>
```

## 5. Structured Data

Добавьте schema.org разметку на ключевых страницах:
- Главная: Organization
- Отели: Hotel
- Блог: Article

## 6. Оптимизация изображений

```bash
# Используйте WebP формат
# Оптимизируйте с помощью:
npm install -g imageoptim-cli
imageoptim --imagealpha images/
```

## 7. Проверка производительности

```bash
# Google Lighthouse
npx lighthouse https://yourdomain.com --view

# Желаемые результаты:
# Performance: > 90
# SEO: > 95
# Best Practices: > 90
# Accessibility: > 90
```

## 8. Мониторинг позиций

Используйте:
- Google Search Console (бесплатно)
- Ahrefs (платно)
- SEMrush (платно)

## 9. Контент-стратегия

### Регулярно публикуйте:
- Гайды по направлениям
- Сезонные предложения
- Новости туризма
- Советы путешественникам

### Целевой объем:
- Блог посты: 1500-2500 слов
- Обновляйте старый контент каждые 6 месяцев

## 10. Link Building

### Внутренние ссылки:
- Связывайте похожие направления
- Используйте анкоры с ключевыми словами
- Создавайте hub-страницы

### Внешние ссылки:
- Гостевые посты
- Партнёрские обзоры
- Туристические форумы
- Социальные сети

## Чек-лист SEO аудита

```markdown
### Technical SEO
- [ ] Sitemap.xml отправлен
- [ ] Robots.txt настроен
- [ ] HTTPS включен
- [ ] Mobile-friendly
- [ ] Page speed > 90
- [ ] No broken links
- [ ] Canonical URLs

### On-Page SEO
- [ ] Уникальные title теги
- [ ] Meta descriptions < 160 символов
- [ ] H1 на каждой странице
- [ ] Alt теги на изображениях
- [ ] Structured data
- [ ] Internal linking

### Content
- [ ] Качественный контент
- [ ] Регулярные обновления
- [ ] Ключевые слова
- [ ] Уникальность > 90%
```

## Полезные инструменты

- **Проверка сайта:** https://web.dev/measure
- **Анализ скорости:** https://pagespeed.web.dev
- **SEO аудит:** https://seositecheckup.com
- **Broken links:** https://ahrefs.com/broken-link-checker
- **Keyword research:** Google Keyword Planner
