# TravelHub Frontend

React + TypeScript приложение с Vite

## Установка

```bash
npm install
```

## Запуск

```bash
npm run dev
```

## Сборка

```bash
npm run build
```
