<?
$site_title      = "U R N The Country Of";
$travel_id       = "83700";
$email           = "jennifer@alnicoproducts.com";
$site_name       = "My Travel Site";
$site_url        = "http://www.urnthecountryof.com/";
?>
