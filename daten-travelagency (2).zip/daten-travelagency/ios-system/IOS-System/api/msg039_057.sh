Задачи:
- Slack connector
- Google Drive sync
- Microsoft 365 integration
- Webhook system
- REST API webhooks

Цель: 5+ major integrations