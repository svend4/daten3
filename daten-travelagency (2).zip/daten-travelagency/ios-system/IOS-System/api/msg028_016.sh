□ Background tasks (Celery)
□ RBAC (role-based access control)
□ API versioning
□ WebUI admin panel (базовый)
□ Multi-language support