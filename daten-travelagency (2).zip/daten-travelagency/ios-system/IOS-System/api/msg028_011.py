# ⚠️ НЕ РЕАЛИЗОВАНО: API versioning
# /api/v1/, /api/v2/ и т.д.