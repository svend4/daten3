□ PyPI package
□ npm package (JS клиент)
□ Maven package (Android)
□ CLI tool
□ VS Code extension