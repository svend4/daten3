# Install MkDocs
pip install mkdocs mkdocs-material

# Create mkdocs.yml