# Build documentation site
mkdocs build

# Preview locally
mkdocs serve
# Open: http://localhost:8000

# Deploy to GitHub Pages
mkdocs gh-deploy

# Now live at: https://your-org.github.io/ios-system/