# 1. Создать миграции
python manage.py makemigrations

# 2. Применить миграции
python manage.py migrate

# 3. Создать superuser
python manage.py createsuperuser