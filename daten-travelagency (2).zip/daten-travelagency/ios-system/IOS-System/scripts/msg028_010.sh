□ Kubernetes deployment
□ Horizontal scaling поддержка
□ Database sharding
□ Read replicas
□ CDN для файлов