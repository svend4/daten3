□ Open source release
□ Documentation site
□ Community forum
□ Contributor guide
□ Case studies