# ⚠️ Prometheus/Grafana описаны, но не pre-configured
# Нужны готовые dashboards