# ❌ НЕЛЬЗЯ СДЕЛАТЬ:
pip install ios-system

# ✅ НУЖНО СОЗДАТЬ:
- setup.py / pyproject.toml
- Build на PyPI
- Versioning