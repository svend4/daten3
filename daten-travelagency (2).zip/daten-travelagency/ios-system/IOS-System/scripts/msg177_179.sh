# Создать scripts/deploy.sh
# Скопировать из ФАЙЛА 19, секция "Deployment Script"

chmod +x scripts/deploy.sh