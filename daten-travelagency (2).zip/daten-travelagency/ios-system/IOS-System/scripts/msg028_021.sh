□ Setup development environment
□ Создать main.py с интеграцией
□ Написать первый end-to-end тест
□ Протестировать на 1 документе