Задачи:
- Native iOS app
- Native Android app
- Offline support
- Push notifications
- Mobile-optimized UI

Цель: Full mobile experience