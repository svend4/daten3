# Blog post
# Post to:
# - Company blog
# - Medium
# - Dev.to
# - Hashnode

# Social media
# - Twitter thread
# - LinkedIn post
# - Reddit (r/programming, r/selfhosted)
# - Hacker News

# Communities
# - Product Hunt launch
# - GitHub Trending
# - Awesome Lists

# Press
# - Tech publications
# - Industry newsletters