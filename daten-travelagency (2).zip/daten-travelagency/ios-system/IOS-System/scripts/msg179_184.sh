# Покажи мне:
1. Структуру проекта (tree)
2. Основные файлы (models.py, views.py, etc.)
3. package.json (для frontend)
4. README с инструкциями

# Я проведу:
- Code review
- Gap analysis
- Recommendations