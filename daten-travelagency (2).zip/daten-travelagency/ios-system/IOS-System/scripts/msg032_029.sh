python scripts/prepare_test_data.py

# Expected output:
# ✓ Sample documents created
#   Location: test_data/sgb_ix
#   Files: 3