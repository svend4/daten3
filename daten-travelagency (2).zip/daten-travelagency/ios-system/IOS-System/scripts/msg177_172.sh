mkdir -p ios_core/settings
touch ios_core/settings/__init__.py
touch ios_core/settings/base.py
touch ios_core/settings/development.py
touch ios_core/settings/production.py