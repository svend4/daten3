# 1. Собрать feedback
# 2. Исправить critical bugs
# 3. Оптимизировать bottlenecks
# 4. Deploy hotfixes если нужно