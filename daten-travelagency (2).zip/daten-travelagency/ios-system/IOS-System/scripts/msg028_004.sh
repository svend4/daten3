# ⚠️ Docker Compose хорош для dev, но для production нужно:
- Kubernetes manifests
- Helm charts
- Terraform modules
- AWS/GCP/Azure templates