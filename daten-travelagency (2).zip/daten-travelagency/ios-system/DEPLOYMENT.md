# 🚀 Варианты тестирования и деплоя IOS System

**Обновлено:** 2025-12-13

---

## 1️⃣ GitHub Actions (Автоматическое тестирование) ✅

### Что делает:
- ✅ Автоматически запускает тесты при каждом push
- ✅ Проверяет код (linting)
- ✅ Собирает Docker образ
- ✅ Показывает статус в PR

### Как активировать:

**Уже настроено!** Файл `.github/workflows/ci.yml` создан.

При следующем push в ветку GitHub Actions автоматически:
1. Запустит PostgreSQL и Redis
2. Установит зависимости
3. Запустит тесты
4. Соберет Docker образ
5. Покажет результаты

### Посмотреть результаты:
- Зайдите на GitHub в ваш репозиторий
- Вкладка **"Actions"**
- Увидите статус всех проверок

### Badge для README:
```markdown
[![CI Status](https://github.com/svend4/daten/workflows/IOS%20System%20CI%2FCD/badge.svg)](https://github.com/svend4/daten/actions)
```

---

## 2️⃣ Railway.app (Бесплатный деплой) 🚂

### Преимущества:
- ✅ **Бесплатно**: $5 кредитов в месяц
- ✅ **PostgreSQL + Redis включены**
- ✅ **Автоматический деплой** при push в GitHub
- ✅ **HTTPS и домен** бесплатно
- ✅ **Логи в реальном времени**

### Как развернуть:

1. **Зарегистрироваться на Railway**
   ```
   https://railway.app
   ```
   - Войти через GitHub

2. **Создать новый проект**
   - New Project → Deploy from GitHub repo
   - Выбрать репозиторий `svend4/daten`

3. **Добавить сервисы**
   - Add Service → Database → PostgreSQL
   - Add Service → Database → Redis

4. **Настроить переменные окружения**
   Railway автоматически подключит:
   - `DATABASE_URL` - от PostgreSQL
   - `REDIS_URL` - от Redis

   Добавить вручную:
   - `SECRET_KEY` = (сгенерировать случайную строку)
   - `ENVIRONMENT` = production

5. **Deploy!**
   - Railway автоматически соберет и запустит
   - Получите URL типа: `https://ios-system-production.up.railway.app`

### Файлы уже созданы:
- ✅ `railway.toml` - конфигурация Railway
- ✅ `Procfile` - команда запуска

---

## 3️⃣ Render.com (Бесплатный деплой) 🎨

### Преимущества:
- ✅ **Бесплатно навсегда** (free tier)
- ✅ **PostgreSQL включен**
- ✅ **Автодеплой** из GitHub
- ✅ **Европейский регион** (Frankfurt)
- ✅ **SSL сертификаты** бесплатно

### Как развернуть:

1. **Зарегистрироваться на Render**
   ```
   https://render.com
   ```
   - Войти через GitHub

2. **Создать Blueprint**
   - New → Blueprint
   - Выбрать репозиторий `svend4/daten`
   - Render автоматически найдет `render.yaml`

3. **Deploy**
   - Render создаст:
     - Web Service (Python app)
     - PostgreSQL Database
     - Redis instance
   - URL: `https://ios-system.onrender.com`

### Файлы уже созданы:
- ✅ `render.yaml` - Blueprint конфигурация

**⚠️ Внимание:** Free tier засыпает после 15 минут неактивности (холодный старт ~30 сек)

---

## 4️⃣ Heroku (Классический деплой) 🟣

### Преимущества:
- ✅ **Проверенная платформа**
- ✅ **PostgreSQL + Redis аддоны**
- ✅ **Deploy кнопка** для одного клика

### Как развернуть:

1. **Deploy Button** (самый простой способ)

   Добавьте в README:
   ```markdown
   [![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/svend4/daten)
   ```

2. **Или через Heroku CLI**
   ```bash
   # Установить Heroku CLI
   curl https://cli-assets.heroku.com/install.sh | sh

   # Login
   heroku login

   # Создать app
   heroku create ios-system-demo

   # Добавить аддоны
   heroku addons:create heroku-postgresql:essential-0
   heroku addons:create heroku-redis:mini

   # Deploy
   git push heroku main

   # Открыть
   heroku open
   ```

### Файлы уже созданы:
- ✅ `Procfile` - команда запуска
- ✅ `app.json` - конфигурация для Deploy Button

**⚠️ Внимание:** С ноября 2022 Heroku убрал бесплатный tier. Минимум $5/месяц.

---

## 5️⃣ GitHub Codespaces (Разработка в браузере) 💻

### Преимущества:
- ✅ **Полноценная IDE в браузере**
- ✅ **60 часов бесплатно в месяц**
- ✅ **Все сервисы в контейнере**
- ✅ **Тестирование без локальной установки**

### Как запустить:

1. **Открыть репозиторий на GitHub**

2. **Code → Codespaces → Create codespace**

3. **Внутри Codespace:**
   ```bash
   cd информационная-ОС

   # Запустить сервисы
   docker-compose up -d postgres redis

   # Установить зависимости
   pip install -r requirements.txt

   # Запустить приложение
   python -m uvicorn ios_bootstrap.main:app --reload
   ```

4. **VS Code предложит открыть порт 8000**
   - Откроется в браузере
   - URL типа: `https://...github.dev`

---

## 6️⃣ DigitalOcean App Platform 🌊

### Преимущества:
- ✅ **$200 кредитов при регистрации**
- ✅ **Managed PostgreSQL**
- ✅ **Автоматический SSL**
- ✅ **CDN включен**

### Как развернуть:

1. **Зарегистрироваться на DigitalOcean**
   ```
   https://www.digitalocean.com
   ```

2. **Create App**
   - Apps → Create App
   - Connect GitHub repo
   - Выбрать `svend4/daten`

3. **Настроить**
   - Type: Web Service
   - Build Command: `cd информационная-ОС && pip install -r requirements.txt`
   - Run Command: `cd информационная-ОС && uvicorn ios_bootstrap.main:app --host 0.0.0.0 --port 8080`

4. **Добавить Database**
   - Add Database → PostgreSQL
   - Автоматически подключится через $DATABASE_URL

---

## 7️⃣ Fly.io (Глобальный Edge деплой) 🪰

### Преимущества:
- ✅ **Бесплатный tier** (3 shared-cpu VMs)
- ✅ **Глобальная сеть** (edge locations)
- ✅ **PostgreSQL + Redis**
- ✅ **Очень быстрый**

### Как развернуть:

1. **Установить flyctl**
   ```bash
   curl -L https://fly.io/install.sh | sh
   ```

2. **Login**
   ```bash
   fly auth login
   ```

3. **Launch app**
   ```bash
   cd информационная-ОС
   fly launch
   # Следовать инструкциям
   ```

4. **Добавить сервисы**
   ```bash
   fly postgres create
   fly redis create
   ```

5. **Deploy**
   ```bash
   fly deploy
   ```

---

## 📊 СРАВНЕНИЕ ПЛАТФОРМ

| Платформа | Бесплатно | PostgreSQL | Redis | Автодеплой | SSL | Регион |
|-----------|-----------|------------|-------|------------|-----|--------|
| **Railway** | ✅ $5/мес | ✅ | ✅ | ✅ | ✅ | 🇺🇸 |
| **Render** | ✅ | ✅ | ✅ | ✅ | ✅ | 🇪🇺 🇺🇸 |
| **Heroku** | ❌ $5+ | ✅ | ✅ | ✅ | ✅ | 🇺🇸 🇪🇺 |
| **Fly.io** | ✅ | ✅ | ✅ | ✅ | ✅ | 🌍 Global |
| **DigitalOcean** | ✅ $200 | ✅ | ❌ | ✅ | ✅ | 🌍 |
| **Codespaces** | ✅ 60h | ⚠️ Docker | ⚠️ Docker | ❌ | ❌ | - |

---

## 🎯 РЕКОМЕНДАЦИИ

### Для быстрого тестирования:
**→ Railway.app** или **Render.com**
- Самая простая настройка
- Всё из коробки
- Бесплатно

### Для разработки:
**→ GitHub Codespaces**
- Не нужно ничего устанавливать
- Полноценная среда разработки
- Бесплатно 60 часов/месяц

### Для production:
**→ Fly.io** или **DigitalOcean**
- Лучшая производительность
- Больше контроля
- Глобальная сеть

### Для демо:
**→ Render.com** (Европа)
- Бесплатно навсегда
- SSL из коробки
- Frankfurt регион

---

## 🚀 БЫСТРЫЙ СТАРТ (Railway)

**1 минута до деплоя:**

1. Зайти на https://railway.app
2. Sign up with GitHub
3. New Project → Deploy from GitHub
4. Выбрать `svend4/daten`
5. Add PostgreSQL
6. Add Redis
7. Generate Domain
8. **Готово!** 🎉

URL будет типа: `https://ios-system-production.up.railway.app`

Проверить: `https://...up.railway.app/health`

---

## ⚠️ ВАЖНО: GitHub Pages НЕ подходит

**GitHub Pages:**
- ❌ Только статические файлы (HTML, JS, CSS)
- ❌ Нет Python backend
- ❌ Нет баз данных
- ❌ Нет server-side кода

**Для нашего проекта нужен:**
- ✅ Python runtime
- ✅ PostgreSQL database
- ✅ Redis cache
- ✅ Server-side execution

→ Используйте Railway, Render или Fly.io вместо GitHub Pages

---

## 📝 СЛЕДУЮЩИЕ ШАГИ

1. **Сейчас:** Push код в GitHub
   ```bash
   git push origin main
   ```

2. **GitHub Actions автоматически:**
   - Запустит тесты
   - Соберет Docker образ
   - Покажет статус

3. **Для публичного demo:**
   - Выбрать платформу (Railway рекомендуется)
   - Deploy в 1 клик
   - Получить публичный URL

4. **Обновить README с badges:**
   ```markdown
   [![CI](https://github.com/svend4/daten/workflows/CI/badge.svg)](https://github.com/svend4/daten/actions)
   [![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=...)
   ```

---

**Готово к деплою! 🚀**
